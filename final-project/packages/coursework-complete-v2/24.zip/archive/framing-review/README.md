# Group 24 review bundle

Start with **report.pdf**: cover, three required coursework tasks and one exploratory grouping appendix (five pages).
This is a REVIEW DRAFT. Four contributor names and each student's honest peer evaluation remain human tasks.
No submission has been made. Names or contributions were not invented.

The core reports the already frozen evaluation. The new appendix reports a nested experiment inside original TRAIN after prior dataset exploration; it does not reopen original validation/test and is not a fresh population test. The two stages are labelled separately and their scores should not be compared directly.

The original coursework PDF is preserved byte for byte at `archive/original-coursework/report.pdf`.
The earlier categorical supplement remains byte for byte at `archive/categorical-review/research-supplement.pdf`, with its report/audit files below `archive/categorical-review/research/`.
Current source/navigation is under `code/`; older overwritten navigation is retained under `archive/previous-navigation/`.
Aggregate evidence is under `evidence/`, including every grouping candidate, all six selected arms, secondary endpoints and subgroup results. No raw ratings, identity lists, score arrays or checkpoints are distributed.

## Reproduce and review

Use `code/README.md` for the core experiment, `code/exploratory/categorical_reconstruction/README.md` for the categorical extension, and `code/exploratory/framing_search/predictive/README.md` for the nested grouping experiment. The latter requires the separately obtained MovieLens100K data and original split/hash prerequisites; the originals are intentionally not redistributed. The exact experiment invocation and source/runtime hashes are in `evidence/framing-predictive-v1/protocol.json`.

From `code/`, run the synthetic tests with the verified numerical environment:

```sh
python -m unittest discover -s exploratory/framing_search/predictive -p 'test_*.py' -v
python -m unittest exploratory.framing_search.recording_audit.test_audit -v
```

To regenerate the five-page PDF from the packaged public evidence/content, use a Python environment with Matplotlib and pypdf, installed Times New Roman regular/bold fonts, and a new output directory:

```sh
python exploratory/framing_search/build_review.py --render-packaged .. --report-dir ../rerendered
```

This reads only packaged aggregate evidence/content. It does not fit or evaluate a recommender. `PACKAGE-MANIFEST.json` binds every other entry; `REPORT-MANIFEST.json` records font digests, exact discussion counts and separate evidence stages. ZIP CRC and extracted-source imports were checked during assembly. Fonts, assignment slides and external datasets are not bundled.
