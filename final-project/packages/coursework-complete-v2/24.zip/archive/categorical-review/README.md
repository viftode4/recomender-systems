# Group 24 research review bundle

Status: REVIEW DRAFT. This archive is not a submission receipt. Four member
names/contributions remain deferred unless supplied in the accompanying report;
no peer contributions or assessments are invented.

Read `report.pdf` for the original, frozen coursework study. Its exact bytes
are preserved from the independently verified original group archive.
Read `research-supplement.pdf` for later categorical-reconstruction research.
The supplement uses reused development data after the original dataset TEST
was viewed; it is not new held-out confirmation and does not amend the original
test tables. Detailed new tables are in `research/research-supplement.md` and
`evidence/categorical-reconstruction-v1/RESULTS.md`.

## Contents and verification

- `code/`: original runnable project source plus the separate new study under
  `exploratory/categorical_reconstruction/`.
- `evidence/`: curated aggregate evidence only; no user histories or scores.
- `research/`: exact supplement artifacts, audit receipt and report manifest.
- `research/group-audit.json`: independent replay of every reported user/item
  group metric, bound to the measured aggregate files and verifier source.
- `PACKAGE-MANIFEST.json`: SHA-256 of every other archive entry.
- `original-package-manifest.json`: historical seal of the original archive;
  it describes that original archive, including entries not carried here.

Both PDF files are review drafts. The new supplement has one page, Times New
Roman 12pt, spacing 1.15, and 110 discussion words.
Original PDF SHA-256: 08888a2ce58b6fe9ae8200c785e185bdaa0acba247c26f8e719123a8759d2fe0
Original archive SHA-256: 7e1d86708471b0d70a4be375ff7211f69a12505802d626e951f2a0fdbc4fd0bb

## Run the independent new-model tests

Use a Python environment with NumPy and SciPy. The measured fitting environment
was Python 3.11.15, NumPy
1.26.4 and SciPy
1.17.1. Rendering additionally
requires `code/requirements-report.txt` and locally installed Times New Roman
regular/bold fonts. Font files and third-party datasets are not redistributed.

From the extracted archive root:

```sh
cd code
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 python -m unittest discover -s exploratory/categorical_reconstruction -p 'test_*.py' -v
```

## Rebuild the measured supplement

From `code/`, with the same source files and a rendering environment:

```sh
python exploratory/categorical_reconstruction/render_supplement.py --evidence ../evidence/categorical-reconstruction-v1 --audit ../research/evidence-audit.json --out ../rebuilt-supplement --group 24 --member 'Vlad George Iftode'
```

Supply only actual contributor names. Output directories must be new. The
renderer verifies the evidence and source hashes before drawing any results;
it never fits models or reads ratings. `research/report-content.json` binds the
displayed numbers to the curated evidence. Font hashes are in the report seal.

## Repeat fitting

The standalone model API and exact runner commands are documented in
`code/exploratory/categorical_reconstruction/README.md`; the protocol and
derivation are alongside it. Full study reproduction first requires the public
MovieLens data, the original TRAIN/VALID partitions, cohort definitions and
locked reference runs described by the project instructions in `code/README.md`.
Those raw inputs and reference prediction arrays are deliberately not packaged.
They must be regenerated through the declared source pipeline, with identities
and fingerprints verified; aggregate tables alone cannot reconstruct them.
Use fresh output paths and keep the exploration label. Rebuilding code does
not restore the original TEST to an unexamined state.

Existing source-document links were written relative to the complete repository.
In this archive, source is under `code/`, evidence is its sibling, and reports
are at the archive root. Use the entry points above for the extracted layout.
The package builder performs no network upload or course submission.
