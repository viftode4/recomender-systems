# Group 24 coursework review

Start with [report.pdf](report.pdf): cover, three required task pages and one grouping appendix.
This remains a review draft while actual contributor details and individual peer feedback are deferred.
Nothing has been uploaded or submitted.

The original frozen test results are unchanged. Task 1 separately labels the later coursework
completion study on reused validation cohorts. The grouping appendix uses its own nested original-TRAIN
assessment. These stages cannot be compared as a single leaderboard or fresh confirmations.

Follow [REPRODUCE.md](code/REPRODUCE.md) for dependencies, data prerequisites and exact commands.
[Coverage](code/coursework_completion/COVERAGE.md) maps the lecture families and assignment tasks.
[Team review](code/coursework_completion/TEAM_REVIEW.md) records the human handoff.
Public aggregate evidence is under `evidence/`; executable sources are under `code/`.
The prior five-page report is preserved at [archive/framing-review/report.pdf](archive/framing-review/report.pdf),
and the original seven-page report at [archive/original-coursework/report.pdf](archive/original-coursework/report.pdf).

From `code/`, regenerate the current PDF without data, model fitting or any previous archive:

```sh
python coursework_completion/build_review.py --render-packaged .. --report-dir ../rerendered
```

This requires the pinned rendering dependencies and installed Times New Roman regular/bold fonts.
It verifies public evidence and all package hashes before rendering. Use a fresh output directory.
`PACKAGE-MANIFEST.json` binds every included artifact. Raw ratings, user histories, prediction arrays,
model checkpoints, external font files and the copyrighted course slides are deliberately excluded.
The separate `verification.json` supplied beside the ZIP records extraction, test and PDF-replay checks.
It is outside the ZIP so its archive hash does not create a circular dependency.
Older narratives are retained for provenance; their explicitly labelled source-checkout references
do not imply that omitted historical artifacts are included in this archive.
